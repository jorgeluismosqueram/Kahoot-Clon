import { mostrar } from "./mostrar.js";
import { preguntas, vectorPreguntas } from "./preguntas.js";
import { } from "./preguntas.js";

var cancion = new Audio("../canciones/cancionfondo.mp3");
cancion.play();
var correctas = 0;
var incorrecta = 0;
var contador = 0;
//  setInterval(mostrar,1000);
mostrar();





